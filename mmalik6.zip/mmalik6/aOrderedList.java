import java.util.Arrays;

/**
 * aOrderedList: This class implements a generic ordered list, allowing
 * insertion of Comparable objects while maintaining the order defined by the
 * natural ordering of the objects.
 *
 * CSC 1351 Programming Project No <1>
 * Section <2>
 *
 * @author <Mujtaba Malik>
 * @since <3/17/24>
 *
 */

public class aOrderedList {

    private final int SIZEINCREMENTS = 20; // the initial max size an ordered list can be
    private Comparable[] oList; // the ordered list itself
    private int listSize; // the size of the ordered list. NOTE: it will initially be the same as SIZEINCREMENTS, but may increase over time 
    private int numObjects; // the number of objects in the ordered list. The rest of the elements in the list will be null until a comparable object is added
    private int curr; // index of current element accessed by the itterator methods

    public aOrderedList() {
        numObjects = 0;
        listSize = SIZEINCREMENTS;
        oList = new Comparable[SIZEINCREMENTS];
    }


    /*
     * reset - resets the iterator to the beginning of the list
     */
    public void reset() {
        curr = 0;
    }


    /*
     * next - moves the iterator to the next element in list and returns that
     * element
     * 
     * @return - The comparable object that is at the iterators location after being
     * moved
     */
    public Comparable next() {
        curr++;
        return oList[curr];
    }


    /*
     * hasNext - checks if iterator can move up
     * 
     * @return - True if the iterator will be able to move to the next element and
     * false if it cannot
     */
    public boolean hasNext() {
        if (curr > numObjects)
            return true;
        else
            return false;
    }


    /*
     * removeCurr - removes current element on iterator
     */
    public void removeCurr() {
        for (int i = curr; i < numObjects - 1; i++) {
            oList[i] = oList[i + 1];
        }
        oList[curr] = null;
        numObjects--;
    }


    /*
     * size - to see the current number of objects in a list(NOTE: the number of
     * objects is not equal to the actual size of the list)
     * 
     * @return - the current value of numObjects
     */
    public int size() {
        return numObjects;
    }


    /*
     * get - grabs a specific objects from the oList
     * 
     * @index - an integer of the index for the object you would like to recieve
     * 
     * @return - The object in the list whose element is the index inputed
     */
    public Comparable get(int index) {
        return oList[index];
    }


    /*
     * isEmpty - checks to see if there are no items inside the list
     * 
     * @return - true if there are no objects inside the list and false if there is
     * at least 1
     */
    public boolean isEmpty() {
        if (numObjects == 0)
            return false;
        else
            return true;
    }


    /*
     * add - adds a comparable object into the list after all the other objects of
     * the same type. If list is full, a new copy of the list + 1 extra slot for the
     * input will be replacing the list
     * 
     * @newObj - the object you would like to append to the list
     */
    public void add(Comparable newObj) {
        if (numObjects == listSize) {
            listSize++;
            Comparable[] tempOList = Arrays.copyOf(oList, listSize);
            oList = tempOList;
        }
        oList[numObjects] = newObj;
        numObjects++;
        // to handle manual sorting utilizing the compareTO method implemented in the
        // comparible object's class
        if (numObjects > 1)
            for (int i = numObjects - 1; i > 0; i--) {
                if (oList[i].compareTo(oList[i - 1]) <= -1) {
                    // swap values in array
                    Comparable tempObj = oList[i];
                    oList[i] = oList[i - 1];
                    oList[i - 1] = tempObj;
                } else
                    break; // quit loop when element is put into right place
            }
    }


    /*
     * remove - removes an object from the list and shifts all the other object to
     * fill in the gap
     * 
     * @index - an integer of the index for the object you would like to remove
     */
    public void remove(int index) {
        if (index < 0 || index >= numObjects)
            throw new IndexOutOfBoundsException("The index " + index + " is out of bounds");
        for (int i = index; i < numObjects - 1; i++) {
            oList[i] = oList[i + 1];
        }
        oList[numObjects - 1] = null;
        numObjects--;
    }


    /*
     * toString - utilizes the toString method of the comparable object's class to
     * call that method for every object in the list
     * NOTE: in order to use this method, the comparable object MUST have a toString
     * method that can be accesed by this class
     * 
     * @return - the string for the toString method for all the objects inthe class
     */
    public String toString() {
        String sumString = "";
        for (int i = 0; i < numObjects; i++)
            sumString += "[" + oList[i].toString() + "] ";
        sumString = sumString.substring(0, sumString.length() - 1); // to remove the space after the last bracket
                                                                    // closes.
        return sumString;
    }

}
