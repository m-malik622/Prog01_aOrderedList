/**
 * Car:Represents a Car object with attributes such as make, year, and price. Implements Comparable interface for comparing Car objects based on their make and then year.
 *
 * CSC 1351 Programming Project No <1>
 * Section <2>
 *
 * @author <Mujtaba Malik>
 * @since <3/17/24>
 *
 */
public class Car implements Comparable<Car> {
    private String make;
    private int year;
    private int price;

    public Car(String make, int year, int price) {
        this.make = make;
        this.year = year;
        this.price = price;
    }

    
    /*
    getMake - safely access the make of the car instance
    @return - returns the string make
    */
    public String getMake() {
        return make;
    }


/*
    getMake - safely access the year of the car instance
    @return - returns the int year
    */
    public int getYear() {
        return year;
    }


    /*
    getMake - safely access the price of the car instance
    @return - returns the int price
    */
    public int getPrice() {
        return price;
    }

    
    /*
    toString - compares to another Car object
    @return - return s string displaying the information of the objects make, year, and price attributes
    */     
    public String toString() {
        return ("Make: " + make + ", Year: " + year + ", Price: " + price + ";");
    }
    
    
    /*
    compareTo - compares to another Car object's make. If both the makes are the same, it will compare the year
    @other - the other CAR object that this CAR object is being compared to
    @return - Negative value if this car is lower than the other, a 0 if both are the same, and a positive number if this car is higher than the other 
    */
    @Override
    public int compareTo(Car other) {
        if (this.make.compareTo(other.make)==0)
            return Integer.compare(this.year, other.getYear());
        else
            return this.make.compareTo(other.make); 
    }
}
