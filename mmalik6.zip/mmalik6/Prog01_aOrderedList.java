import java.io.FileNotFoundException;
import java.io.File;
import java.io.PrintWriter;
import java.util.Scanner;

/**
 * Prog01_aOrderedList: Contains main method that is designed to specifically
 * handle the Car object. Utilizes external methods for creating and error
 * checking a Scanner and PrintWriter object for a user prompted txt file. The
 * main method also utilizes the aOrderedList class to store Car objects
 * and performs add and delete operations on the list based on the first CSV of
 * each input file line.
 *
 * CSC 1351 Programming Project No <1>
 * Section <2>
 *
 * @author <Mujtaba Malik>
 * @since <3/17/24>
 *
 */
public class Prog01_aOrderedList {

    /**
     * Main: Prompts user for input and output file and formats the CAR object's
     * members
     *
     * @throws FileNotFoundException if an external method throws one
     */
    public static void main(String[] args) throws FileNotFoundException {
        Scanner userInputScanner = new Scanner(System.in);
        try {
            System.out.println("Enter input filename: ");
            Scanner fileScanner = GetInputFile(userInputScanner.next());
            aOrderedList orderedList = new aOrderedList();

            while (fileScanner.hasNextLine()) {
                String line = fileScanner.nextLine();
                String[] commaSeperatedVals = line.split(",");
                char indicatorChar = commaSeperatedVals[0].charAt(0);

                if (indicatorChar == 'A') {
                    String userMake = commaSeperatedVals[1];
                    int userYear = Integer.parseInt(commaSeperatedVals[2]);
                    int userPrice = Integer.parseInt(commaSeperatedVals[3]);
                    Car userCar = new Car(userMake, userYear, userPrice);
                    orderedList.add(userCar);
                } else if (indicatorChar == 'D') {
                    String userMake = commaSeperatedVals[1];
                    int userYear = Integer.parseInt(commaSeperatedVals[2]);
                    for (int i = 0; i < orderedList.size(); i++) {
                        if (userMake.equals(((Car) orderedList.get(i)).getMake())
                                && userYear == ((Car) orderedList.get(i)).getYear()) {
                            orderedList.remove(i);
                        }
                    }
                }
            }
            System.out.println("Enter Output filename: ");
            PrintWriter fileWriter = GetOutputFile(userInputScanner.next());
            String orderedListString = "Number of cars: " + orderedList.size();
            int carIndex = 0;
            while (carIndex < orderedList.size()) {
                orderedListString += String.format("\n\nMake:\t%s\nYear:\t%d\nPrice:\t$%,d",
                        ((Car) orderedList.get(carIndex)).getMake(), ((Car) orderedList.get(carIndex)).getYear(),
                        ((Car) orderedList.get(carIndex)).getPrice());
                carIndex++;
            }
            fileWriter.println(orderedListString);
            fileScanner.close();
            fileWriter.close();
        } catch (FileNotFoundException e) {
            System.out.println("File does not exist and user chose not to continue.");
        } finally {
            userInputScanner.close();
        }
    }

    /*
     * GenInputFile - asks user to input text file name; creates a file and scanner
     * object for the file, and handles FileNotFoundException
     * 
     * @userInput - a string of a path to the text file includingthe
     * ".txt extension"
     * 
     * @return - A scanner object for the file inputed, given that it exists within
     * the specified path. If user chooses to exit method, will return null and main
     * method will handle the exception from there.
     * 
     * @throws FileNotFoundException if the user types 'n' when being prompted to
     * contunue. The main method should handle the rest from there
     */
    public static Scanner GetInputFile(String userInput) throws FileNotFoundException {
        File fileName = new File(userInput);
        if (fileName.isFile()) {
            Scanner fileScanner = new Scanner(fileName);
            return fileScanner;
        } else {
            Scanner tempScan = new Scanner(System.in);
            System.out.println("File specified <" + userInput + "> does not exist. Would you like to continue? <Y/N>");
            String response = tempScan.next().toLowerCase().trim();

            if (response.equals("y")) {
                System.out.println("Enter input filename: ");
                return GetInputFile(tempScan.next());
            } else {
                tempScan.close();
                throw new FileNotFoundException();
            }
        }
    }

    /*
     * GetOutputFile - asks user to input text file name; creates a file and scanner
     * object for the file, and handles FileNotFoundException
     * 
     * @userPrompt - a string of a path to the text file including the
     * ".txt extension"
     * 
     * @return - A PrintWriter object for the file inputed, given that it exists
     * within
     * the specified path. If user chooses to exit method, the method will throw a
     * FileNotFoundExceptionwill and the main
     * method can handle the exception from there.
     * 
     * @throws FileNotFoundException if the user types 'n' when being prompted to
     * contunue. The main method should handle the rest from there
     */
    public static PrintWriter GetOutputFile(String UserPrompt) throws FileNotFoundException {
        File fileName = new File(UserPrompt);
        if (fileName.isFile()) {
            PrintWriter fileWriter = new PrintWriter(fileName);
            return fileWriter;
        } else {
            Scanner tempScan = new Scanner(System.in);
            System.out.println("File specified <" + UserPrompt + "> does not exist. Would you like to continue? <Y/N>");
            String response = tempScan.next().toLowerCase().trim();

            if (response.equals("y")) {
                System.out.println("Enter output filename: ");
                return GetOutputFile(tempScan.next()); // tempscan will only close if user chooses 'N'
            } else {
                tempScan.close();
                throw new FileNotFoundException();
            }
        }
    }

}
